import { toast } from "sonner";

const messages = [
  "🏖️ Our app is on vacation in Pokhara — sipping milk tea. Back soon!",
  "🚀 Coming Soon! The app is still doing its morning yoga.",
  "🧘 App is meditating in the Himalayas. Enlightenment loading…",
  "🍜 App stepped out for momos. Will be right back!",
  "🐢 Coming Soon! Our app is taking the scenic route.",
  "☕ App is still on its chiya break. Patience, friend!",
  "🎒 App went trekking to Everest Base Camp. Updates from the summit soon!",
];

export function showComingSoon() {
  const msg = messages[Math.floor(Math.random() * messages.length)];
  toast(msg, {
    description: "We're launching very soon — stay tuned!",
    duration: 3500,
  });
}
