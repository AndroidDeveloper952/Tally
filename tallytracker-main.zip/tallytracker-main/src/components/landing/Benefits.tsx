import { Check, Star } from "lucide-react";

const benefits = [
  "Better money management without spreadsheets",
  "Save more every month with smart insights",
  "Fast tracking — under 5 seconds per entry",
  "No accounting knowledge required",
  "Works offline, syncs when you're online",
  "Localized for Nepali rupee and habits",
];

const reviews = [
  {
    name: "Anish Shrestha",
    role: "Kathmandu · Freelancer",
    quote: "Now I finally understand where my money goes! The weekly insights changed how I spend.",
    rating: 5,
  },
  {
    name: "Priya Maharjan",
    role: "Lalitpur · Student",
    quote: "Super simple and very useful for daily budgeting. I've saved Rs 8,000 in just two months.",
    rating: 5,
  },
  {
    name: "Bibek Karki",
    role: "Pokhara · Business owner",
    quote: "Best finance tracker app I've used. The dashboard feels like a real banking product.",
    rating: 5,
  },
];

export function Benefits() {
  return (
    <section className="relative py-24 bg-gradient-soft">
      <div className="mx-auto max-w-6xl px-4 grid lg:grid-cols-2 gap-12 items-center">
        <div>
          <div className="inline-flex items-center gap-2 rounded-full bg-card px-3 py-1 text-xs font-semibold text-primary">
            Why Tally Tracker
          </div>
          <h2 className="mt-4 text-3xl sm:text-4xl font-bold">
            Real benefits, <span className="text-gradient">real results</span>
          </h2>
          <p className="mt-4 text-muted-foreground">
            Built around the way people in Nepal actually earn, spend and save. Not a generic budgeting tool.
          </p>

          <ul className="mt-8 grid sm:grid-cols-2 gap-3">
            {benefits.map((b) => (
              <li key={b} className="flex items-start gap-3 rounded-2xl bg-card p-4 shadow-card">
                <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-gradient-primary text-primary-foreground">
                  <Check className="h-3.5 w-3.5" />
                </span>
                <span className="text-sm font-medium">{b}</span>
              </li>
            ))}
          </ul>
        </div>

        <div id="reviews" className="space-y-4">
          {reviews.map((r, i) => (
            <div
              key={r.name}
              className="rounded-3xl glass shadow-soft p-6 animate-fade-up"
              style={{ animationDelay: `${i * 100}ms` }}
            >
              <div className="flex items-center gap-1 text-yellow-500">
                {Array.from({ length: r.rating }).map((_, idx) => (
                  <Star key={idx} className="h-4 w-4 fill-current" />
                ))}
              </div>
              <p className="mt-3 text-foreground font-medium">"{r.quote}"</p>
              <div className="mt-4 flex items-center gap-3">
                <div className="grid h-10 w-10 place-items-center rounded-full bg-gradient-primary text-primary-foreground font-bold">
                  {r.name[0]}
                </div>
                <div>
                  <div className="text-sm font-semibold">{r.name}</div>
                  <div className="text-xs text-muted-foreground">{r.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
