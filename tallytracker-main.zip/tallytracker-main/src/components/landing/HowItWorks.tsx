import { PlusCircle, BarChart3, Trophy } from "lucide-react";

const steps = [
  {
    icon: PlusCircle,
    title: "Add your income & expenses",
    desc: "Quick entry with smart categories. Takes under 5 seconds per transaction.",
  },
  {
    icon: BarChart3,
    title: "View charts and reports",
    desc: "Automatic, beautiful breakdowns of where every rupee goes — daily, weekly, monthly.",
  },
  {
    icon: Trophy,
    title: "Improve savings & control",
    desc: "Get personalized insights, hit savings goals, and build healthy money habits.",
  },
];

export function HowItWorks() {
  return (
    <section id="how" className="relative py-24 bg-gradient-soft">
      <div className="mx-auto max-w-6xl px-4">
        <div className="text-center max-w-2xl mx-auto">
          <div className="inline-flex items-center gap-2 rounded-full bg-card px-3 py-1 text-xs font-semibold text-primary">
            How it works
          </div>
          <h2 className="mt-4 text-3xl sm:text-4xl font-bold">
            Three simple steps to <span className="text-gradient">financial clarity</span>
          </h2>
        </div>

        <div className="mt-16 relative grid md:grid-cols-3 gap-8">
          {/* connecting line */}
          <div className="hidden md:block absolute top-10 left-[16%] right-[16%] h-px bg-gradient-to-r from-primary/40 via-secondary/40 to-primary/40" />

          {steps.map((s, i) => (
            <div
              key={s.title}
              className="relative text-center animate-fade-up"
              style={{ animationDelay: `${i * 120}ms` }}
            >
              <div className="relative mx-auto h-20 w-20">
                <div className="absolute inset-0 rounded-full bg-gradient-primary blur-xl opacity-40" />
                <div className="relative grid h-20 w-20 place-items-center rounded-full bg-gradient-primary text-primary-foreground shadow-glow">
                  <s.icon className="h-8 w-8" />
                </div>
                <div className="absolute -top-2 -right-2 h-8 w-8 grid place-items-center rounded-full bg-card border border-border text-xs font-bold text-primary">
                  {i + 1}
                </div>
              </div>
              <h3 className="mt-6 text-xl font-semibold">{s.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground max-w-xs mx-auto">{s.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
