import { useEffect, useRef, useState } from "react";
import {
  ArrowRight,
  Sparkles,
  TrendingUp,
  ArrowUpRight,
  ArrowDownRight,
  Wallet,
  Mail,
  Zap,
  Coffee,
  Bus,
  ShoppingBag,
  Plus,
  Send,
  Repeat,
  PiggyBank,
  Bell,
  Apple,
  Play,
} from "lucide-react";
import { Link } from "@tanstack/react-router";
import { showComingSoon } from "@/lib/coming-soon";
import { toast } from "sonner";

function playChargingSound() {
  const AudioCtx = (window as any).AudioContext || (window as any).webkitAudioContext;
  if (!AudioCtx) return;
  const ctx = new AudioCtx();

  const master = ctx.createGain();
  master.gain.value = 0.25;
  master.connect(ctx.destination);

  const osc = ctx.createOscillator();
  const oscGain = ctx.createGain();
  osc.type = "sawtooth";
  osc.frequency.setValueAtTime(120, ctx.currentTime);
  osc.frequency.exponentialRampToValueAtTime(2400, ctx.currentTime + 1.6);
  oscGain.gain.setValueAtTime(0, ctx.currentTime);
  oscGain.gain.linearRampToValueAtTime(1, ctx.currentTime + 0.15);
  oscGain.gain.setValueAtTime(1, ctx.currentTime + 1.4);
  oscGain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 2.0);
  osc.connect(oscGain);
  oscGain.connect(master);
  osc.start(ctx.currentTime);
  osc.stop(ctx.currentTime + 2.1);

  const osc2 = ctx.createOscillator();
  const osc2Gain = ctx.createGain();
  osc2.type = "square";
  osc2.frequency.setValueAtTime(300, ctx.currentTime);
  osc2.frequency.exponentialRampToValueAtTime(5000, ctx.currentTime + 1.8);
  osc2Gain.gain.setValueAtTime(0, ctx.currentTime);
  osc2Gain.gain.linearRampToValueAtTime(0.12, ctx.currentTime + 0.3);
  osc2Gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 2.0);
  osc2.connect(osc2Gain);
  osc2Gain.connect(master);
  osc2.start(ctx.currentTime);
  osc2.stop(ctx.currentTime + 2.1);

  const bufferSize = ctx.sampleRate * 2.2;
  const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
  const data = noiseBuffer.getChannelData(0);
  for (let i = 0; i < bufferSize; i++) data[i] = Math.random() * 2 - 1;
  const noise = ctx.createBufferSource();
  noise.buffer = noiseBuffer;
  const noiseGain = ctx.createGain();
  const noiseFilter = ctx.createBiquadFilter();
  noiseFilter.type = "bandpass";
  noiseFilter.frequency.setValueAtTime(2000, ctx.currentTime);
  noiseFilter.frequency.linearRampToValueAtTime(8000, ctx.currentTime + 1.5);
  noiseGain.gain.setValueAtTime(0, ctx.currentTime);
  noiseGain.gain.linearRampToValueAtTime(0.15, ctx.currentTime + 0.2);
  noiseGain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 2.0);
  noise.connect(noiseFilter);
  noiseFilter.connect(noiseGain);
  noiseGain.connect(master);
  noise.start(ctx.currentTime);
  noise.stop(ctx.currentTime + 2.2);
}

function useCountUp(target: number, duration = 1600) {
  const [value, setValue] = useState(0);
  const ref = useRef<HTMLDivElement | null>(null);
  const started = useRef(false);
  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && !started.current) {
            started.current = true;
            const start = performance.now();
            const tick = (t: number) => {
              const p = Math.min(1, (t - start) / duration);
              const eased = 1 - Math.pow(1 - p, 3);
              setValue(Math.round(target * eased));
              if (p < 1) requestAnimationFrame(tick);
            };
            requestAnimationFrame(tick);
            observer.disconnect();
          }
        });
      },
      { threshold: 0.3 }
    );
    observer.observe(node);
    return () => observer.disconnect();
  }, [target, duration]);
  return { value, ref };
}

/* ---------- Countdown ---------- */
const LAUNCH_KEY = "tt_launch_ts";
function makeLaunchTs(): number {
  const hours = 24 + Math.floor(Math.random() * 49); // 24–72h
  return Date.now() + hours * 3600_000;
}
function readOrCreateLaunchTs(): number {
  const raw = localStorage.getItem(LAUNCH_KEY);
  if (raw) {
    const n = parseInt(raw, 10);
    if (!Number.isNaN(n) && n > Date.now()) return n;
  }
  const ts = makeLaunchTs();
  localStorage.setItem(LAUNCH_KEY, String(ts));
  return ts;
}

function LaunchCountdown({ showNotify }: { showNotify?: boolean }) {
  const [mounted, setMounted] = useState(false);
  const [target, setTarget] = useState<number>(0);
  const [now, setNow] = useState<number>(0);

  useEffect(() => {
    setMounted(true);
    setTarget(readOrCreateLaunchTs());
    setNow(Date.now());
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);

  // Countdown runs until the app is published — no auto-restart.

  if (!mounted || target === 0) {
    return <div className="mt-6 max-w-md mx-auto h-[112px]" aria-hidden />;
  }

  if (showNotify) {
    return (
      <div className="mt-6 max-w-md mx-auto animate-notify-down">
        <div className="relative overflow-hidden rounded-2xl border border-white/40 dark:border-white/10 bg-white/80 dark:bg-slate-900/70 backdrop-blur-xl px-4 py-3 shadow-glow flex items-center gap-3">
          <div className="grid h-10 w-10 place-items-center rounded-2xl bg-gradient-primary text-primary-foreground shadow-soft shrink-0">
            <Bell className="h-5 w-5 animate-notify-shake" />
          </div>
          <div className="flex-1 min-w-0 text-left">
            <div className="flex items-center gap-2 text-sm font-bold text-foreground">
              Coming Soon
              <span className="text-[10px] font-semibold uppercase tracking-widest text-primary">Tally Tracker</span>
            </div>
            <p className="text-xs text-muted-foreground truncate">
              The app is almost ready — hang tight, launching soon!
            </p>
          </div>
          <div className="absolute inset-x-0 bottom-0 h-[3px] bg-gradient-primary origin-left animate-notify-progress" />
        </div>
      </div>
    );
  }

  const diff = Math.max(0, target - now);

  const isLive = diff === 0;
  const h = Math.floor(diff / 3600_000);
  const m = Math.floor((diff % 3600_000) / 60_000);
  const s = Math.floor((diff % 60_000) / 1000);
  const pad = (n: number) => n.toString().padStart(2, "0");

  if (isLive) {
    return (
      <div className="mt-6 max-w-md mx-auto text-center rounded-2xl border border-emerald-300/60 dark:border-emerald-700/50 bg-gradient-to-r from-emerald-50 to-teal-50 dark:from-emerald-950/40 dark:to-teal-950/40 p-5 shadow-soft animate-confetti">
        <div className="flex items-center justify-center gap-2 text-emerald-700 dark:text-emerald-300 font-bold">
          <span className="relative flex h-2.5 w-2.5">
            <span className="animate-pulse-dot absolute inline-flex h-full w-full rounded-full bg-emerald-500 opacity-75" />
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500" />
          </span>
          We are Live now
        </div>
        <p className="mt-1 text-sm text-muted-foreground">
          You can download Tally Tracker on iOS and Play Store.
        </p>
        <div className="mt-4 flex flex-wrap justify-center gap-2">
          <button
            onClick={showComingSoon}
            className="inline-flex items-center gap-2 rounded-xl bg-foreground text-background px-4 py-2.5 text-sm font-semibold hover:opacity-90 transition"
          >
            <Apple className="h-4 w-4" />
            <div className="text-left leading-tight">
              <div className="text-[9px] opacity-70">Download on the</div>
              <div className="text-xs font-bold">App Store</div>
            </div>
          </button>
          <button
            onClick={showComingSoon}
            className="inline-flex items-center gap-2 rounded-xl bg-foreground text-background px-4 py-2.5 text-sm font-semibold hover:opacity-90 transition"
          >
            <Play className="h-4 w-4" />
            <div className="text-left leading-tight">
              <div className="text-[9px] opacity-70">GET IT ON</div>
              <div className="text-xs font-bold">Google Play</div>
            </div>
          </button>
        </div>
      </div>
    );
  }

  const Cell = ({ v, label }: { v: string; label: string }) => (
    <div className="flex flex-col items-center">
      <div className="relative min-w-[58px] rounded-xl bg-gradient-to-b from-foreground to-foreground/85 text-background px-3 py-2 text-2xl font-bold tabular-nums shadow-soft">
        {v}
      </div>
      <div className="mt-1 text-[10px] uppercase tracking-widest text-muted-foreground">{label}</div>
    </div>
  );

  return (
    <div className="mt-6 max-w-md mx-auto text-center rounded-2xl glass p-4 shadow-soft">
      <div className="flex items-center justify-center gap-2 text-xs font-semibold text-primary">
        <Bell className="h-3.5 w-3.5" />
        Launching in
      </div>
      <div className="mt-3 flex items-center justify-center gap-2">
        <Cell v={pad(h)} label="Hours" />
        <span className="text-2xl font-bold text-muted-foreground/60">:</span>
        <Cell v={pad(m)} label="Minutes" />
        <span className="text-2xl font-bold text-muted-foreground/60">:</span>
        <Cell v={pad(s)} label="Seconds" />
      </div>
    </div>
  );
}

/* ---------- Redesigned Mobile UI ---------- */
type DeviceType = "ios" | "android";

function AppScreen() {
  const bars = [45, 62, 38, 78, 55, 88, 70];
  const days = ["M", "T", "W", "T", "F", "S", "S"];

  return (
    <div className="flex flex-col h-full">
      {/* App header */}
      <div className="px-5 pt-2 pb-2 flex items-center justify-between shrink-0">
        <div>
          <div className="text-[10px] text-muted-foreground font-medium">Namaste,</div>
          <div className="text-sm font-bold text-foreground">Ram 👋</div>
        </div>
        <div className="h-9 w-9 rounded-full bg-gradient-primary grid place-items-center text-primary-foreground text-xs font-bold shadow-soft">
          R
        </div>
      </div>

      {/* Balance card */}
      <div
        className="mx-4 rounded-3xl p-4 text-white relative overflow-hidden shadow-[0_20px_40px_-15px_oklch(0.6_0.2_200/0.55)] shrink-0"
        style={{
          background:
            "linear-gradient(135deg, oklch(0.55 0.16 165) 0%, oklch(0.5 0.18 205) 55%, oklch(0.42 0.18 260) 100%)",
        }}
      >
        <div aria-hidden className="absolute -right-8 -top-8 h-32 w-32 rounded-full bg-white/10 blur-2xl" />
        <div aria-hidden className="absolute -left-6 -bottom-10 h-28 w-28 rounded-full bg-white/10 blur-2xl" />
        <div className="relative flex items-center justify-between text-[10px] uppercase tracking-widest opacity-90">
          <span>Total balance</span>
          <Wallet className="h-3.5 w-3.5" />
        </div>
        <div className="relative mt-1.5 text-[26px] font-bold tabular-nums">Rs 84,250</div>
        <div className="relative mt-0.5 flex items-center gap-1 text-[11px] opacity-90">
          <TrendingUp className="h-3 w-3" />
          +12.4% this month
        </div>
        <div className="relative mt-3 grid grid-cols-4 gap-2">
          {[
            { Icon: Plus, label: "Add" },
            { Icon: Send, label: "Send" },
            { Icon: Repeat, label: "Swap" },
            { Icon: PiggyBank, label: "Save" },
          ].map(({ Icon, label }) => (
            <button
              key={label}
              className="flex flex-col items-center gap-1 rounded-xl bg-white/15 backdrop-blur px-2 py-2 hover:bg-white/25 transition"
            >
              <Icon className="h-3.5 w-3.5" />
              <span className="text-[9px] font-semibold">{label}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="px-4 mt-3 grid grid-cols-2 gap-2.5 shrink-0">
        <div className="rounded-2xl bg-white p-3 shadow-[0_2px_10px_-2px_oklch(0.5_0.05_220/0.12)] border border-black/[0.03]">
          <div className="flex items-center gap-1.5">
            <div className="grid h-5 w-5 place-items-center rounded-full bg-emerald-100">
              <ArrowDownRight className="h-3 w-3 text-emerald-600" />
            </div>
            <span className="text-[10px] font-semibold text-muted-foreground">Income</span>
          </div>
          <div className="mt-1 text-sm font-bold text-foreground tabular-nums">Rs 42,000</div>
          <div className="text-[9px] text-emerald-600 font-medium">+8.2%</div>
        </div>
        <div className="rounded-2xl bg-white p-3 shadow-[0_2px_10px_-2px_oklch(0.5_0.05_220/0.12)] border border-black/[0.03]">
          <div className="flex items-center gap-1.5">
            <div className="grid h-5 w-5 place-items-center rounded-full bg-rose-100">
              <ArrowUpRight className="h-3 w-3 text-rose-600" />
            </div>
            <span className="text-[10px] font-semibold text-muted-foreground">Expense</span>
          </div>
          <div className="mt-1 text-sm font-bold text-foreground tabular-nums">Rs 18,750</div>
          <div className="text-[9px] text-rose-600 font-medium">-3.4%</div>
        </div>
      </div>

      <div className="mx-4 mt-3 rounded-2xl bg-white p-3 shadow-[0_2px_10px_-2px_oklch(0.5_0.05_220/0.12)] border border-black/[0.03] shrink-0">
        <div className="flex items-center justify-between">
          <span className="text-[10px] font-bold text-foreground">Weekly spend</span>
          <span className="text-[9px] text-primary font-semibold">This week</span>
        </div>
        <div className="mt-2 flex items-end gap-1.5 h-14">
          {bars.map((h, i) => (
            <div key={i} className="flex-1 flex flex-col items-center gap-1">
              <div
                className="w-full rounded-t-md bg-gradient-to-t from-[oklch(0.55_0.16_165)] to-[oklch(0.72_0.2_195)] animate-grow-bar"
                style={{ height: `${h}%`, animationDelay: `${i * 70}ms` }}
              />
              <span className="text-[8px] text-muted-foreground font-medium">{days[i]}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="mx-4 mt-3 flex-1 min-h-0 overflow-hidden">
        <div className="flex items-center justify-between mb-1.5">
          <span className="text-[10px] font-bold text-foreground">Recent</span>
          <span className="text-[9px] text-primary font-semibold">See all</span>
        </div>
        <div className="space-y-1.5">
          {[
            { Icon: Coffee, tint: "amber", name: "Himalayan Java", cat: "Coffee · Today", amt: "-Rs 320" },
            { Icon: Wallet, tint: "emerald", name: "Salary", cat: "Income · Oct 1", amt: "+Rs 42,000" },
            { Icon: Bus, tint: "sky", name: "Pathao ride", cat: "Travel · Yesterday", amt: "-Rs 180" },
          ].map((t) => {
            const tintMap: Record<string, string> = {
              amber: "bg-amber-100 text-amber-700",
              emerald: "bg-emerald-100 text-emerald-700",
              sky: "bg-sky-100 text-sky-700",
            };
            const positive = t.amt.startsWith("+");
            return (
              <div key={t.name} className="flex items-center justify-between rounded-xl bg-white px-2.5 py-2 border border-black/[0.03]">
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className={`grid h-7 w-7 place-items-center rounded-full ${tintMap[t.tint]}`}>
                    <t.Icon className="h-3.5 w-3.5" />
                  </div>
                  <div className="min-w-0">
                    <div className="text-[11px] font-semibold text-foreground truncate">{t.name}</div>
                    <div className="text-[9px] text-muted-foreground truncate">{t.cat}</div>
                  </div>
                </div>
                <div className={`text-[11px] font-bold tabular-nums ${positive ? "text-emerald-600" : "text-foreground"}`}>
                  {t.amt}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function IPhoneFrame({ children }: { children: React.ReactNode }) {
  return (
    <div
      className="relative mx-auto w-[300px] sm:w-[330px] aspect-[9/18] rounded-[3rem] p-[10px] animate-float ring-1 ring-white/10 shadow-[0_0_60px_-5px_oklch(0.7_0.28_160/0.85),0_0_120px_-10px_oklch(0.6_0.3_235/0.7),0_30px_60px_-15px_oklch(0.55_0.25_200/0.6),inset_0_0_0_1.5px_oklch(0.35_0.02_240)]"
      style={{
        background:
          "linear-gradient(145deg, oklch(0.28 0.015 250) 0%, oklch(0.18 0.01 250) 35%, oklch(0.22 0.012 250) 65%, oklch(0.14 0.008 250) 100%)",
      }}
    >
      <div aria-hidden className="absolute left-[-3px] top-[100px] h-7 w-[3px] rounded-l bg-[oklch(0.3_0.01_250)]" />
      <div aria-hidden className="absolute left-[-3px] top-[138px] h-12 w-[3px] rounded-l bg-[oklch(0.3_0.01_250)]" />
      <div aria-hidden className="absolute left-[-3px] top-[184px] h-12 w-[3px] rounded-l bg-[oklch(0.3_0.01_250)]" />
      <div aria-hidden className="absolute right-[-3px] top-[150px] h-20 w-[3px] rounded-r bg-[oklch(0.3_0.01_250)]" />

      <div
        className="relative h-full w-full rounded-[2.5rem] overflow-hidden"
        style={{
          background:
            "linear-gradient(180deg, oklch(0.98 0.008 200) 0%, oklch(0.96 0.012 210) 100%)",
        }}
      >
        {/* Dynamic Island */}
        <div
          aria-hidden
          className="absolute top-2 left-1/2 -translate-x-1/2 z-30 h-[26px] w-[100px] rounded-full bg-black flex items-center justify-end pr-2.5"
        >
          <div className="h-1.5 w-1.5 rounded-full bg-[oklch(0.4_0.05_200)]" />
        </div>

        {/* iOS status bar */}
        <div className="relative z-10 flex items-center justify-between px-6 pt-3 pb-1 text-[10px] font-semibold text-foreground/80">
          <span>9:41</span>
          <span className="opacity-0">.</span>
        </div>

        {children}

        {/* Home indicator */}
        <div aria-hidden className="absolute bottom-1.5 left-1/2 -translate-x-1/2 h-1 w-24 rounded-full bg-black/40" />
      </div>
    </div>
  );
}

function AndroidFrame({ children }: { children: React.ReactNode }) {
  return (
    <div
      className="relative mx-auto w-[300px] sm:w-[330px] aspect-[9/19] rounded-[2.4rem] p-[8px] animate-float ring-1 ring-white/10 shadow-[0_0_60px_-5px_oklch(0.7_0.28_160/0.85),0_0_120px_-10px_oklch(0.6_0.3_235/0.7),0_30px_60px_-15px_oklch(0.55_0.25_200/0.6),inset_0_0_0_1.5px_oklch(0.4_0.02_240)]"
      style={{
        background:
          "linear-gradient(145deg, oklch(0.22 0.01 260) 0%, oklch(0.14 0.008 260) 100%)",
      }}
    >
      {/* Power + volume */}
      <div aria-hidden className="absolute right-[-3px] top-[130px] h-16 w-[3px] rounded-r bg-[oklch(0.32_0.01_260)]" />
      <div aria-hidden className="absolute left-[-3px] top-[120px] h-20 w-[3px] rounded-l bg-[oklch(0.32_0.01_260)]" />

      <div
        className="relative h-full w-full rounded-[2rem] overflow-hidden"
        style={{
          background:
            "linear-gradient(180deg, oklch(0.98 0.008 200) 0%, oklch(0.96 0.012 210) 100%)",
        }}
      >
        {/* Punch-hole camera */}
        <div
          aria-hidden
          className="absolute top-2 left-1/2 -translate-x-1/2 z-30 h-[12px] w-[12px] rounded-full bg-black ring-2 ring-[oklch(0.2_0.01_260)]"
        />

        {/* Android status bar */}
        <div className="relative z-10 flex items-center justify-between px-4 pt-1.5 pb-1 text-[10px] font-semibold text-foreground/80">
          <span>9:41</span>
          <span className="flex items-center gap-1 opacity-70">
            <span className="text-[9px]">5G</span>
            <span className="inline-block h-2 w-3 rounded-sm border border-current" />
          </span>
        </div>

        {children}

        {/* Gesture pill */}
        <div aria-hidden className="absolute bottom-1 left-1/2 -translate-x-1/2 h-[3px] w-28 rounded-full bg-black/40" />
      </div>
    </div>
  );
}

function MockDashboard({ device }: { device: DeviceType }) {
  const Frame = device === "ios" ? IPhoneFrame : AndroidFrame;
  return (
    <div className="relative">
      {/* Neon aura */}
      <div aria-hidden className="pointer-events-none absolute -inset-10 -z-10">
        <div className="absolute inset-0 rounded-[3rem] blur-3xl opacity-90 bg-[radial-gradient(circle_at_50%_50%,oklch(0.7_0.28_160/0.95),oklch(0.6_0.3_235/0.8)_45%,transparent_70%)]" />
        <div className="absolute inset-4 rounded-[3rem] blur-2xl opacity-80 bg-[radial-gradient(circle_at_50%_60%,oklch(0.78_0.25_175/0.95),transparent_65%)]" />
      </div>

      <Frame>
        <AppScreen />
      </Frame>
    </div>
  );
}

function DeviceToggle({ device, onChange }: { device: DeviceType; onChange: (d: DeviceType) => void }) {
  const options: { id: DeviceType; label: string; sub: string }[] = [
    { id: "ios", label: "iPhone", sub: "17 Pro Max" },
    { id: "android", label: "Android", sub: "Galaxy S26 Ultra" },
  ];
  return (
    <div className="mx-auto mb-5 inline-flex items-center gap-1 rounded-full glass p-1 shadow-soft">
      {options.map((o) => {
        const active = device === o.id;
        return (
          <button
            key={o.id}
            onClick={() => onChange(o.id)}
            className={`relative rounded-full px-4 py-1.5 text-xs font-semibold transition-all ${
              active
                ? "bg-gradient-primary text-primary-foreground shadow-soft"
                : "text-muted-foreground hover:text-foreground"
            }`}
            aria-pressed={active}
          >
            <span className="block leading-tight">{o.label}</span>
            <span className={`block text-[9px] font-medium leading-tight ${active ? "opacity-90" : "opacity-60"}`}>
              {o.sub}
            </span>
          </button>
        );
      })}
    </div>
  );
}


const COUNTER_NAMESPACE = "tallytracker";
const COUNTER_KEY = "waitlist";

async function fetchWaitlistCount(): Promise<number | null> {
  try {
    const res = await fetch(`https://abacus.jasoncameron.dev/get/${COUNTER_NAMESPACE}/${COUNTER_KEY}`);
    if (!res.ok) return null;
    const data = await res.json();
    return typeof data.value === "number" ? data.value : null;
  } catch {
    return null;
  }
}

async function incrementWaitlistCount(): Promise<number | null> {
  try {
    const res = await fetch(`https://abacus.jasoncameron.dev/hit/${COUNTER_NAMESPACE}/${COUNTER_KEY}`);
    if (!res.ok) return null;
    const data = await res.json();
    return typeof data.value === "number" ? data.value : null;
  } catch {
    return null;
  }
}

export function Hero() {
  const users = useCountUp(50000);
  const tracked = useCountUp(120);
  const rating = useCountUp(49);
  const [email, setEmail] = useState("");
  const [joined, setJoined] = useState(false);
  const [waitlistCount, setWaitlistCount] = useState<number | null>(null);
  const [downloadNotify, setDownloadNotify] = useState(false);
  const [device, setDevice] = useState<DeviceType>("ios");

  useEffect(() => {
    let cancelled = false;
    fetchWaitlistCount().then((v) => {

      if (!cancelled && v !== null) setWaitlistCount(v);
    });
    const interval = setInterval(() => {
      fetchWaitlistCount().then((v) => {
        if (!cancelled && v !== null) setWaitlistCount(v);
      });
    }, 8000);
    return () => {
      cancelled = true;
      clearInterval(interval);
    };
  }, []);

  useEffect(() => {
    if (!downloadNotify) return;
    const t = setTimeout(() => setDownloadNotify(false), 3000);
    return () => clearTimeout(t);
  }, [downloadNotify]);

  const handleWaitlist = async (e: React.FormEvent) => {
    e.preventDefault();

    const value = email.trim();
    const valid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
    if (!valid) {
      toast.error("Please enter a valid email address");
      return;
    }
    const joinedKey = "tt_waitlist_joined";
    const alreadyJoined = localStorage.getItem(joinedKey) === "1";
    if (!alreadyJoined) {
      const newCount = await incrementWaitlistCount();
      if (newCount !== null) setWaitlistCount(newCount);
      localStorage.setItem(joinedKey, "1");
    }
    playChargingSound();
    setJoined(true);
    setEmail("");
    toast.success("Congratulations! You are on the waitlist!", {
      description: "We'll email you the moment Tally Tracker launches.",
    });
  };

  return (
    <section className="relative pt-32 pb-20 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-hero -z-10" />
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-border to-transparent -z-10" />

      <div className="mx-auto max-w-6xl px-4 grid lg:grid-cols-2 gap-12 items-center">
        <div className="animate-fade-up">
          <div className="inline-flex items-center gap-2 rounded-full glass px-4 py-1.5 text-xs font-semibold text-primary">
            <Sparkles className="h-3.5 w-3.5" />
            Built for Nepal · Free to start
          </div>

          <h1 className="mt-6 text-4xl sm:text-5xl lg:text-6xl font-bold leading-[1.05]">
            Take control of your money,{" "}
            <span className="text-gradient">one tap at a time.</span>
          </h1>

          <p className="mt-6 text-lg text-muted-foreground max-w-xl">
            Tally Tracker makes tracking income, expenses and savings effortless.
            Beautiful charts, smart insights and zero spreadsheets — designed for everyday life in Nepal.
          </p>

          <LaunchCountdown showNotify={downloadNotify} />

          <div className="mt-6 flex items-center gap-2 text-sm text-muted-foreground">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-pulse-dot absolute inline-flex h-full w-full rounded-full bg-emerald-500 opacity-75" />
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500" />
            </span>
            <span className="font-medium text-foreground">{Math.max(100000, waitlistCount ?? 0).toLocaleString()}+</span> people joined the waitlist · live
          </div>

          {joined && (
            <div className="mt-4 max-w-md animate-confetti rounded-2xl bg-gradient-to-r from-emerald-50 to-teal-50 dark:from-emerald-950/40 dark:to-teal-950/40 border border-emerald-200 dark:border-emerald-800/50 p-4 flex items-start gap-3">
              <div className="mt-0.5 grid h-8 w-8 place-items-center rounded-full bg-gradient-primary shrink-0">
                <Zap className="h-4 w-4 text-primary-foreground" />
              </div>
              <div>
                <div className="text-sm font-bold text-foreground">Congratulations!</div>
                <div className="text-xs text-muted-foreground mt-0.5">You are on the waitlist. We will email you the moment Tally Tracker launches.</div>
              </div>
            </div>
          )}

          {!joined && (
            <form
              onSubmit={handleWaitlist}
              className="mt-4 max-w-md flex items-center gap-2 rounded-full glass p-1.5 pl-4 shadow-soft focus-within:shadow-glow transition-shadow"
            >
              <Mail className="h-4 w-4 text-muted-foreground shrink-0" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email"
                aria-label="Email address"
                className="flex-1 bg-transparent outline-none text-sm placeholder:text-muted-foreground/70 py-2"
              />
              <button
                type="submit"
                className="group inline-flex items-center gap-1.5 rounded-full bg-gradient-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground shadow-soft hover:shadow-glow transition-all hover:-translate-y-0.5"
              >
                Join Waitlist
                <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
              </button>
            </form>
          )}

          <div className="mt-8 flex flex-wrap gap-3">
            <button
              onClick={() => setDownloadNotify(true)}
              className="group inline-flex items-center gap-2 rounded-full bg-gradient-primary px-6 py-3.5 text-sm font-semibold text-primary-foreground shadow-soft hover:shadow-glow transition-all hover:-translate-y-0.5"
            >
              Download App
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </button>
            <Link
              to="/pricing"
              className="inline-flex items-center gap-2 rounded-full glass px-6 py-3.5 text-sm font-semibold hover:bg-white transition-all"
            >
              Get Started Free
            </Link>
          </div>

          <div className="mt-10 grid grid-cols-3 gap-6 max-w-md">
            <div ref={users.ref}>
              <div className="text-2xl font-bold text-gradient">{users.value.toLocaleString()}+</div>
              <div className="text-xs text-muted-foreground mt-1">Active users</div>
            </div>
            <div ref={tracked.ref}>
              <div className="text-2xl font-bold text-gradient">Rs {tracked.value}M+</div>
              <div className="text-xs text-muted-foreground mt-1">Tracked monthly</div>
            </div>
            <div ref={rating.ref}>
              <div className="text-2xl font-bold text-gradient">{(rating.value / 10).toFixed(1)}★</div>
              <div className="text-xs text-muted-foreground mt-1">App rating</div>
            </div>
          </div>
        </div>

        <div className="relative flex flex-col items-center">
          <DeviceToggle device={device} onChange={setDevice} />
          <MockDashboard device={device} />
        </div>
      </div>
    </section>
  );
}
