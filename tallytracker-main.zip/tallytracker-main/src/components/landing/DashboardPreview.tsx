import { useEffect, useState } from "react";

const categories = [
  { name: "Food", pct: 32, color: "oklch(0.68 0.18 155)" },
  { name: "Travel", pct: 22, color: "oklch(0.62 0.18 235)" },
  { name: "Shopping", pct: 18, color: "oklch(0.72 0.16 195)" },
  { name: "Bills", pct: 16, color: "oklch(0.78 0.15 110)" },
  { name: "Other", pct: 12, color: "oklch(0.65 0.2 280)" },
];

function Donut() {
  const [progress, setProgress] = useState(0);
  useEffect(() => {
    const t = setTimeout(() => setProgress(1), 200);
    return () => clearTimeout(t);
  }, []);

  const radius = 70;
  const circ = 2 * Math.PI * radius;
  let offset = 0;

  return (
    <div className="relative w-[200px] h-[200px]">
      <svg viewBox="0 0 200 200" className="-rotate-90">
        <circle cx="100" cy="100" r={radius} fill="none" stroke="oklch(0.95 0.01 200)" strokeWidth="22" />
        {categories.map((c) => {
          const len = (c.pct / 100) * circ * progress;
          const seg = (
            <circle
              key={c.name}
              cx="100"
              cy="100"
              r={radius}
              fill="none"
              stroke={c.color}
              strokeWidth="22"
              strokeDasharray={`${len} ${circ - len}`}
              strokeDashoffset={-offset}
              style={{ transition: "stroke-dasharray 1.2s ease-out" }}
            />
          );
          offset += (c.pct / 100) * circ;
          return seg;
        })}
      </svg>
      <div className="absolute inset-0 grid place-items-center text-center">
        <div>
          <div className="text-xs text-muted-foreground">Spent</div>
          <div className="text-2xl font-bold">Rs 18.7k</div>
        </div>
      </div>
    </div>
  );
}

export function DashboardPreview() {
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun"];
  const data = [30, 55, 42, 70, 60, 85];

  return (
    <section id="preview" className="relative py-24">
      <div className="mx-auto max-w-6xl px-4">
        <div className="text-center max-w-2xl mx-auto">
          <div className="inline-flex items-center gap-2 rounded-full bg-accent px-3 py-1 text-xs font-semibold text-primary">
            Preview
          </div>
          <h2 className="mt-4 text-3xl sm:text-4xl font-bold">
            A dashboard that <span className="text-gradient">tells the whole story</span>
          </h2>
          <p className="mt-4 text-muted-foreground">
            Designed like a premium banking app — at a glance, you'll know exactly how you're doing.
          </p>
        </div>

        <div className="mt-16 relative rounded-[2rem] glass shadow-glow p-6 sm:p-10">
          <div className="grid lg:grid-cols-3 gap-6">
            <div className="rounded-2xl bg-card p-6 shadow-card">
              <div className="text-xs text-muted-foreground">This month</div>
              <div className="mt-1 text-3xl font-bold">Rs 84,250</div>
              <div className="text-xs text-primary font-semibold mt-1">+12.4%</div>

              <div className="mt-6">
                <div className="text-xs font-semibold text-muted-foreground mb-3">Last 6 months</div>
                <div className="flex items-end gap-2 h-32">
                  {data.map((h, i) => (
                    <div key={i} className="flex-1 flex flex-col items-center gap-1">
                      <div
                        className="w-full rounded-t-lg bg-gradient-primary animate-grow-bar"
                        style={{ height: `${h}%`, animationDelay: `${i * 100}ms` }}
                      />
                      <span className="text-[10px] text-muted-foreground">{months[i]}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="rounded-2xl bg-card p-6 shadow-card grid place-items-center">
              <Donut />
              <div className="mt-4 grid grid-cols-2 gap-x-4 gap-y-1.5 w-full">
                {categories.map((c) => (
                  <div key={c.name} className="flex items-center gap-2 text-xs">
                    <span className="h-2 w-2 rounded-full" style={{ background: c.color }} />
                    <span className="text-muted-foreground">{c.name}</span>
                    <span className="ml-auto font-semibold">{c.pct}%</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="rounded-2xl bg-card p-6 shadow-card">
              <div className="text-xs font-semibold text-muted-foreground">Savings goal</div>
              <div className="mt-2 text-2xl font-bold">Trip to Pokhara</div>
              <div className="mt-4 flex items-baseline gap-2">
                <span className="text-3xl font-bold text-gradient">Rs 17k</span>
                <span className="text-sm text-muted-foreground">/ Rs 25k</span>
              </div>
              <div className="mt-3 h-2 w-full rounded-full bg-muted overflow-hidden">
                <div className="h-full w-[68%] bg-gradient-primary" />
              </div>

              <div className="mt-6 space-y-3">
                {[
                  { name: "Daraz · Headphones", amt: "-Rs 2,400" },
                  { name: "Freelance project", amt: "+Rs 8,000" },
                  { name: "Bhatbhateni groceries", amt: "-Rs 1,250" },
                ].map((t) => (
                  <div key={t.name} className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground truncate pr-2">{t.name}</span>
                    <span className={`font-semibold ${t.amt.startsWith("+") ? "text-primary" : ""}`}>
                      {t.amt}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
