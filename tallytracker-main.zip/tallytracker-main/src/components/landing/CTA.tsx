import { useState } from "react";
import { Apple, Smartphone, ArrowRight, Wallet, Twitter, Instagram, Facebook, Copy, ExternalLink } from "lucide-react";
import { toast } from "sonner";
import { showComingSoon } from "@/lib/coming-soon";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

const contactEmail = "mindspirex52@gmail.com";

export function CTA() {
  return (
    <section id="cta" className="relative py-24">
      <div className="mx-auto max-w-5xl px-4">
        <div className="relative overflow-hidden rounded-[2.5rem] bg-gradient-primary p-10 sm:p-16 text-center text-primary-foreground shadow-glow">
          <div className="absolute -top-20 -right-20 h-64 w-64 rounded-full bg-white/20 blur-3xl" />
          <div className="absolute -bottom-20 -left-20 h-64 w-64 rounded-full bg-white/10 blur-3xl" />

          <div className="relative">
            <h2 className="text-3xl sm:text-5xl font-bold leading-tight">
              Start managing your money <br className="hidden sm:block" /> smarter today.
            </h2>
            <p className="mt-4 text-primary-foreground/90 max-w-xl mx-auto">
              Join 50,000+ users in Nepal already taking control of their finances with Tally Tracker.
            </p>

            <div className="mt-8 flex flex-wrap justify-center gap-3">
              <button
                onClick={showComingSoon}
                className="inline-flex items-center gap-2 rounded-full bg-white px-6 py-3.5 text-sm font-semibold text-primary shadow-soft hover:-translate-y-0.5 transition-all"
              >
                <Apple className="h-4 w-4" />
                Download Now
                <ArrowRight className="h-4 w-4" />
              </button>
              <a
                href="#features"
                className="inline-flex items-center gap-2 rounded-full glass-dark px-6 py-3.5 text-sm font-semibold text-primary-foreground border border-white/30 hover:bg-white/10 transition-all"
              >
                <Smartphone className="h-4 w-4" />
                Explore Features
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export function Footer() {
  const [isContactOpen, setIsContactOpen] = useState(false);

  const handleCopyEmail = async () => {
    try {
      await navigator.clipboard.writeText(contactEmail);
      toast("Email copied", {
        description: `${contactEmail} is ready to paste.`,
        duration: 3000,
      });
    } catch {
      toast("Copy not available", {
        description: `Use this email address: ${contactEmail}`,
        duration: 3500,
      });
    }
  };

  return (
    <footer className="border-t border-border py-12">
      <div className="mx-auto max-w-6xl px-4">
        <div className="grid md:grid-cols-4 gap-8">
          <div className="md:col-span-2">
            <div className="flex items-center gap-2">
              <div className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-primary">
                <Wallet className="h-5 w-5 text-primary-foreground" />
              </div>
              <span className="font-bold text-lg">Tally Tracker</span>
            </div>
            <p className="mt-4 text-sm text-muted-foreground max-w-sm">
              The simplest way to track income, expenses and savings. Built for Nepal, loved everywhere.
            </p>
            <div className="mt-5 flex items-center gap-3">
              {[Twitter, Instagram, Facebook].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  className="grid h-9 w-9 place-items-center rounded-full bg-muted hover:bg-gradient-primary hover:text-primary-foreground transition-colors"
                  aria-label="social"
                >
                  <Icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-sm font-semibold">Product</h4>
            <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
              <li><a href="#features" className="hover:text-foreground">Features</a></li>
              <li><a href="#preview" className="hover:text-foreground">Dashboard</a></li>
              <li><a href="#cta" className="hover:text-foreground">Download</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-semibold">Company</h4>
            <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
              <li><a href="https://sites.google.com/view/tally-privacypolicy" target="_blank" rel="noopener noreferrer" className="hover:text-foreground">Privacy Policy</a></li>
              <li>
                <Dialog open={isContactOpen} onOpenChange={setIsContactOpen}>
                  <DialogTrigger asChild>
                    <button type="button" className="hover:text-foreground">Contact</button>
                  </DialogTrigger>
                  <DialogContent className="max-w-md">
                    <DialogHeader>
                      <DialogTitle>Contact Tally Tracker</DialogTitle>
                      <DialogDescription>
                        Choose the option that works best on your device.
                      </DialogDescription>
                    </DialogHeader>

                    <div className="space-y-3">
                      <div className="rounded-md border border-border bg-muted/40 p-3 text-sm text-foreground break-all">
                        {contactEmail}
                      </div>

                      <div className="flex flex-col gap-3 sm:flex-row">
                        <Button
                          type="button"
                          className="flex-1"
                          onClick={() => {
                            if (typeof window !== "undefined") {
                              const subject = encodeURIComponent("Hello Tally Tracker");
                              const body = encodeURIComponent("Hi Tally Tracker team,\n\nI would like to get in touch with you regarding:\n\n");
                              window.location.href = `mailto:${contactEmail}?subject=${subject}&body=${body}`;
                            }
                          }}
                        >
                          <ExternalLink className="h-4 w-4" />
                          Open Email App
                        </Button>
                        <Button type="button" variant="outline" className="flex-1" onClick={handleCopyEmail}>
                          <Copy className="h-4 w-4" />
                          Copy Email
                        </Button>
                      </div>

                      <p className="text-xs text-muted-foreground">
                        If your browser blocks opening an email app, copy the address and send us a message manually.
                      </p>
                    </div>
                  </DialogContent>
                </Dialog>
              </li>
              <li><a href="#" className="hover:text-foreground">Terms</a></li>
            </ul>
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-border flex flex-col sm:flex-row gap-3 items-center justify-between text-xs text-muted-foreground">
          <span>© {new Date().getFullYear()} Tally Tracker. All rights reserved.</span>
          <span>Made with care in Kathmandu, Nepal.</span>
        </div>
      </div>
    </footer>
  );
}
