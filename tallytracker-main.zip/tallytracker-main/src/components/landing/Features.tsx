import {
  TrendingUp,
  PieChart,
  Target,
  ShieldCheck,
  Tags,
  CalendarRange,
  ArrowRight,
} from "lucide-react";

const features = [
  {
    icon: TrendingUp,
    title: "Income & expense tracking",
    desc: "Log every rupee in seconds with quick-add and smart categorization.",
  },
  {
    icon: CalendarRange,
    title: "Monthly budget planning",
    desc: "Set flexible budgets per category and stay on track all month long.",
  },
  {
    icon: PieChart,
    title: "Real-time analytics",
    desc: "Beautiful charts that show exactly where your money goes — instantly.",
  },
  {
    icon: Tags,
    title: "Category-wise spending",
    desc: "Food, travel, shopping, bills — see your spend breakdown clearly.",
  },
  {
    icon: Target,
    title: "Savings goals tracker",
    desc: "Set goals, get nudges, and watch your savings grow week by week.",
  },
  {
    icon: ShieldCheck,
    title: "Secure local storage",
    desc: "Your financial data stays on your device. End-to-end private by default.",
  },
];

export function Features() {
  return (
    <section id="features" className="relative py-24">
      <div className="mx-auto max-w-6xl px-4">
        <div className="max-w-2xl">
          <div className="inline-flex items-center gap-2 rounded-full bg-accent px-3 py-1 text-xs font-semibold text-primary">
            Features
          </div>
          <h2 className="mt-4 text-3xl sm:text-4xl font-bold">
            Everything you need to <span className="text-gradient">master your money</span>
          </h2>
          <p className="mt-4 text-muted-foreground">
            Thoughtfully designed tools that turn daily transactions into clear, actionable insights.
          </p>
        </div>

        <div className="mt-12 grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {features.map((f, i) => (
            <div
              key={f.title}
              className="group relative rounded-3xl bg-card border border-border p-6 shadow-card hover:shadow-glow transition-all duration-300 hover:-translate-y-1 animate-fade-up"
              style={{ animationDelay: `${i * 70}ms` }}
            >
              <div className="grid h-12 w-12 place-items-center rounded-2xl bg-gradient-soft group-hover:bg-gradient-primary transition-colors">
                <f.icon className="h-6 w-6 text-primary group-hover:text-primary-foreground transition-colors" />
              </div>
              <h3 className="mt-5 text-lg font-semibold">{f.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{f.desc}</p>
              <button className="mt-5 inline-flex items-center gap-1.5 rounded-full border border-border px-4 py-1.5 text-xs font-semibold hover:bg-gradient-primary hover:text-primary-foreground hover:border-transparent transition-all">
                Learn more
                <ArrowRight className="h-3 w-3" />
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
