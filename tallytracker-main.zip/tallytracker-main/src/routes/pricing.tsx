import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Check, ArrowLeft, Copy, Crown, Sparkles, Zap } from "lucide-react";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

const ESEWA_ID = "+977 9749455791";
const ESEWA_NAME = "UDAYA CHANDRA KHATRI";

type Plan = {
  id: "free" | "pro" | "plus";
  name: string;
  price: number;
  period: string;
  tagline: string;
  highlight?: boolean;
  badge?: string;
  icon: typeof Sparkles;
  features: string[];
  cta: string;
};

const plans: Plan[] = [
  {
    id: "free",
    name: "Free",
    price: 0,
    period: "forever",
    tagline: "Start tracking with zero commitment.",
    icon: Sparkles,
    cta: "Get Started Free",
    features: [
      "Track income & expenses",
      "Basic charts & insights",
      "Up to 3 categories",
      "No credit card required",
    ],
  },
  {
    id: "pro",
    name: "Pro",
    price: 25,
    period: "one-time",
    tagline: "Unlock all premium features.",
    highlight: true,
    badge: "Most Popular",
    icon: Zap,
    cta: "Buy Pro Plan",
    features: [
      "Everything in Free",
      "Unlimited categories & accounts",
      "Advanced analytics & reports",
      "Smart AI insights",
      "Priority email support",
    ],
  },
  {
    id: "plus",
    name: "Plus",
    price: 100,
    period: "lifetime",
    tagline: "Lifetime access to everything.",
    badge: "Best Value",
    icon: Crown,
    cta: "Buy Plus Plan",
    features: [
      "Everything in Free & Pro",
      "Lifetime app access",
      "All future updates included",
      "Premium support",
      "Early access to new features",
    ],
  },
];

export const Route = createFileRoute("/pricing")({
  head: () => ({
    meta: [
      { title: "Pricing — Tally Tracker" },
      {
        name: "description",
        content:
          "Simple pricing for Tally Tracker. Start free, upgrade to Pro for premium features, or get Plus for lifetime access.",
      },
      { property: "og:title", content: "Pricing — Tally Tracker" },
      {
        property: "og:description",
        content:
          "Free, Pro, and Plus plans. Pay easily with eSewa. Lifetime access available.",
      },
    ],
  }),
  component: PricingPage,
});

function PricingPage() {
  const [selectedPlan, setSelectedPlan] = useState<Plan | null>(null);

  const handleCta = (plan: Plan) => {
    if (plan.id === "free") {
      toast.success("You're all set! Download the app to begin.", {
        description: "No card needed — start tracking right away.",
      });
      return;
    }
    setSelectedPlan(plan);
  };

  const copy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast.success(`${label} copied!`);
  };

  return (
    <main className="min-h-screen bg-background">
      <div className="absolute inset-0 bg-gradient-hero -z-10" />

      <div className="mx-auto max-w-6xl px-4 py-16 sm:py-24">
        <Link
          to="/"
          className="inline-flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors mb-8"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to home
        </Link>

        <div className="text-center max-w-2xl mx-auto">
          <div className="inline-flex items-center gap-2 rounded-full glass px-4 py-1.5 text-xs font-semibold text-primary">
            <Sparkles className="h-3.5 w-3.5" />
            Simple, transparent pricing
          </div>
          <h1 className="mt-6 text-4xl sm:text-5xl font-bold leading-tight">
            Choose the plan that <span className="text-gradient">fits you</span>
          </h1>
          <p className="mt-4 text-lg text-muted-foreground">
            Start free. Upgrade when you're ready. Pay once with eSewa — no recurring charges.
          </p>
        </div>

        <div className="mt-14 grid md:grid-cols-3 gap-6">
          {plans.map((plan) => {
            const Icon = plan.icon;
            return (
              <div
                key={plan.id}
                className={`relative rounded-3xl p-8 transition-all hover:-translate-y-1 ${
                  plan.highlight
                    ? "bg-gradient-primary text-primary-foreground shadow-glow"
                    : "glass shadow-soft"
                }`}
              >
                {plan.badge && (
                  <div
                    className={`absolute -top-3 left-1/2 -translate-x-1/2 rounded-full px-3 py-1 text-[10px] font-bold uppercase tracking-wider ${
                      plan.highlight
                        ? "bg-white text-primary"
                        : "bg-foreground text-background"
                    }`}
                  >
                    {plan.badge}
                  </div>
                )}

                <div
                  className={`grid h-12 w-12 place-items-center rounded-2xl ${
                    plan.highlight ? "bg-white/20" : "bg-gradient-primary"
                  }`}
                >
                  <Icon
                    className={`h-6 w-6 ${
                      plan.highlight ? "text-white" : "text-primary-foreground"
                    }`}
                  />
                </div>

                <h3 className="mt-5 text-2xl font-bold">{plan.name}</h3>
                <p
                  className={`mt-1 text-sm ${
                    plan.highlight ? "text-primary-foreground/80" : "text-muted-foreground"
                  }`}
                >
                  {plan.tagline}
                </p>

                <div className="mt-6 flex items-baseline gap-1">
                  <span className="text-5xl font-bold">${plan.price}</span>
                  <span
                    className={`text-sm ${
                      plan.highlight ? "text-primary-foreground/80" : "text-muted-foreground"
                    }`}
                  >
                    / {plan.period}
                  </span>
                </div>

                <button
                  onClick={() => handleCta(plan)}
                  className={`mt-6 w-full rounded-full px-5 py-3 text-sm font-semibold transition-all hover:-translate-y-0.5 ${
                    plan.highlight
                      ? "bg-white text-primary shadow-soft"
                      : "bg-gradient-primary text-primary-foreground shadow-soft hover:shadow-glow"
                  }`}
                >
                  {plan.cta}
                </button>

                <ul className="mt-8 space-y-3">
                  {plan.features.map((f) => (
                    <li key={f} className="flex items-start gap-2 text-sm">
                      <Check
                        className={`h-4 w-4 mt-0.5 flex-shrink-0 ${
                          plan.highlight ? "text-white" : "text-primary"
                        }`}
                      />
                      <span
                        className={
                          plan.highlight ? "text-primary-foreground/90" : "text-foreground"
                        }
                      >
                        {f}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            );
          })}
        </div>

        <p className="mt-10 text-center text-sm text-muted-foreground">
          Need help choosing? Email us at{" "}
          <a href="mailto:mindspirex52@gmail.com" className="text-primary font-medium">
            mindspirex52@gmail.com
          </a>
        </p>
      </div>

      <Dialog open={!!selectedPlan} onOpenChange={(o) => !o && setSelectedPlan(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Pay with eSewa</DialogTitle>
            <DialogDescription>
              Send <strong>${selectedPlan?.price}</strong> for the{" "}
              <strong>{selectedPlan?.name}</strong> plan to the eSewa account below.
              After payment, email us your transaction screenshot to activate your plan.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-3 mt-2">
            <div className="rounded-xl border bg-muted/40 p-4">
              <div className="text-xs uppercase tracking-wider text-muted-foreground">
                eSewa ID / Mobile
              </div>
              <div className="mt-1 flex items-center justify-between gap-2">
                <span className="font-mono font-semibold">{ESEWA_ID}</span>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => copy(ESEWA_ID, "eSewa ID")}
                >
                  <Copy className="h-3.5 w-3.5 mr-1" /> Copy
                </Button>
              </div>
            </div>

            <div className="rounded-xl border bg-muted/40 p-4">
              <div className="text-xs uppercase tracking-wider text-muted-foreground">
                Account Name
              </div>
              <div className="mt-1 flex items-center justify-between gap-2">
                <span className="font-semibold">{ESEWA_NAME}</span>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => copy(ESEWA_NAME, "Account name")}
                >
                  <Copy className="h-3.5 w-3.5 mr-1" /> Copy
                </Button>
              </div>
            </div>

            <div className="rounded-xl bg-gradient-primary p-4 text-primary-foreground">
              <div className="text-xs uppercase tracking-wider opacity-80">
                Amount to Pay
              </div>
              <div className="mt-1 text-2xl font-bold">
                ${selectedPlan?.price} USD
              </div>
              <div className="text-xs opacity-80 mt-1">
                Pay equivalent NPR via eSewa
              </div>
            </div>

            <a
              href={`mailto:mindspirex52@gmail.com?subject=${encodeURIComponent(
                `${selectedPlan?.name} Plan Payment - Tally Tracker`,
              )}&body=${encodeURIComponent(
                `Hi Tally Tracker team,\n\nI have paid $${selectedPlan?.price} for the ${selectedPlan?.name} plan via eSewa.\n\nTransaction ID: \nPayment date: \n\n(Please attach your eSewa payment screenshot)\n\nThanks!`,
              )}`}
              className="block w-full rounded-full bg-gradient-primary px-5 py-3 text-sm font-semibold text-primary-foreground text-center shadow-soft hover:shadow-glow transition-all"
            >
              I've Paid — Send Confirmation
            </a>
          </div>
        </DialogContent>
      </Dialog>
    </main>
  );
}
