import { createFileRoute } from "@tanstack/react-router";
import { Navbar } from "@/components/landing/Navbar";
import { Hero } from "@/components/landing/Hero";
import { Features } from "@/components/landing/Features";
import { HowItWorks } from "@/components/landing/HowItWorks";
import { DashboardPreview } from "@/components/landing/DashboardPreview";
import { Benefits } from "@/components/landing/Benefits";
import { CTA, Footer } from "@/components/landing/CTA";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Tally Tracker — Track Income, Expenses & Savings in Nepal" },
      {
        name: "description",
        content:
          "Tally Tracker is the simplest way to track your income, expenses and savings. Beautiful charts, smart insights, designed for Nepal.",
      },
      { property: "og:title", content: "Tally Tracker — Smart Money Tracker" },
      {
        property: "og:description",
        content:
          "Take control of your money, one tap at a time. Track income, expenses and savings effortlessly.",
      },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <main className="min-h-screen bg-background">
      <Navbar />
      <Hero />
      <Features />
      <HowItWorks />
      <DashboardPreview />
      <Benefits />
      <CTA />
      <Footer />
    </main>
  );
}
